import React from "react";
import { TextField, Button } from "@material-ui/core";
import ArrowForwardIosIcon from "@material-ui/icons/ArrowForwardIos";
import axios from "axios";

class ChatWindow extends React.Component {
  state = {
    chatState: { bot1: "hi"},
    counter: 1,
    userQuest: ""
  };

  handleClick = async (e)=>{
    let requestBody = {"queryInput":{
      "text":{
          "text":"Hello",
          "languageCode":"en-US"
        }
      }
    }

    try {
      let response = await fetch(
        "http://localhost:5000/getDF",
        requestBody
      );
      let json = await response.json();
      console.log(json);
    } catch (e) {
      console.log(e);
    }
    console.log(this.state.userQuest);
    this.setState({
      counter: this.state.counter+1
    },()=>{
      // this.setState({
      //   chatState:{...this.state.chatState, obj}
      // })
      let temp = this.state.chatState;
      temp["user"+this.state.counter] = this.state.userQuest;
      temp["bot"+this.state.counter] = "bot response";
      this.setState({
        chatState : temp
      })
      console.log(temp)
    })
  }

  handleAsk = (event)=>{
    
    this.setState({
      userQuest: event.target.value
    },()=>{
      console.log(this.state.userQuest);
    })
  }

  render() {
    return (
      <div className="chatRootWindow">
        <div className="chats">
          {Object.keys(this.state.chatState) != undefined &&
          Object.keys(this.state.chatState).length != 0 ? (
            Object.keys(this.state.chatState).map((key, i) => (
              <div className={key.includes("bot") ? "bot" : "user"}>
                {eval("this.state.chatState." + key)}
              </div>
            ))
          ) : (
            <p>Loading..</p>
          )}
        </div>
        <div className="chatInputDiv">
          <TextField className="txtField" onChange={(event)=>this.handleAsk(event)} id="standard-basic" label="Ask something..." />
          <Button className="sendBtn"  variant="contained" 
                  color="primary" 
                  onClick={(event)=>this.handleClick(event)}>
            <ArrowForwardIosIcon />
          </Button>
        </div>
      </div>
    );
  }
}

export default ChatWindow;
